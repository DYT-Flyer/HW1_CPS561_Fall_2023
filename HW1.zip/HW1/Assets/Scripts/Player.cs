using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    //[SerializeField] private Transform groundCheckTransform = null;
    [SerializeField] private LayerMask playerMask;

    private bool jumpKeyWasPressed;
    private float horizontalInput;
    private Rigidbody rigidbodyComponent;
    private int superJumpsRemaining;
    private bool onPlatform;
    private bool onGrass;
    private Vector3 platformVelocity;
    private Rigidbody platformRb;
    private int direction;
    private int jumpcontrol;
    private Vector3 startPos;

    // Start is called before the first frame update
    void Start()
    {
        rigidbodyComponent = GetComponent<Rigidbody>();
        startPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) == true && jumpcontrol == 1) {
            jumpKeyWasPressed = true;
        }

        horizontalInput = Input.GetAxis("Horizontal");

        if (transform.position.y < -10)
        {
            Respawn();
        }
    }

    private void FixedUpdate()
    {
        //rigidbodyComponent.velocity = new Vector3(horizontalInput * 5, rigidbodyComponent.velocity.y, 0);
        transform.Translate(new Vector3(horizontalInput*.05f, 0, 0));
        if (jumpKeyWasPressed && jumpcontrol == 1)
        {
            rigidbodyComponent.AddForce(Vector3.up * 5, ForceMode.VelocityChange);
            jumpKeyWasPressed = false;
            jumpcontrol = 0;
        }

        if (onPlatform)
        {
            if (direction == 1)
            {
                transform.Translate(.1f, 0, 0);
            } else
            {
                transform.Translate(-.1f, 0, 0);
            }

            onPlatform = false;
        }
    }

    private void OnTriggerEnter (Collider other)
    {
        if (other.gameObject.CompareTag("Coin"))
        {
            Destroy(other.gameObject);
            superJumpsRemaining++;
        }
    }

    private void Respawn()
    {
        transform.position = startPos;
    }

    private void OnCollisionEnter(Collision other)
    {
        jumpcontrol = 1;

        if (other.gameObject.CompareTag("Platform"))
        {
            Platform platform = other.gameObject.GetComponent<Platform>();
            onPlatform = true;
            direction = platform.translate;
        }

        if (other.gameObject.CompareTag("Grass"))
        {
            onGrass = true;
        }
    }

    private void OnCollisionStay(Collision other)
    {
        if (other.gameObject.CompareTag("Platform"))
        {
            Platform platform = other.gameObject.GetComponent<Platform>();
            onPlatform = true;
            direction = platform.translate;
        }
    }
}
