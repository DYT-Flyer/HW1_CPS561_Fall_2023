using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Platform : MonoBehaviour
{
    private Rigidbody rigidBodyComponent;
    public int direction;
    public int translate;
    private Vector3 originalPosition;
    private Vector3 relativePosition;
    private Vector3 rbvelocity;
    private Vector3 update;

    // Start is called before the first frame update
    void Start()
    {
        rigidBodyComponent = GetComponent<Rigidbody>();
        originalPosition = transform.position;
        direction = 1;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        rbvelocity = rigidBodyComponent.velocity;
        relativePosition = transform.position - originalPosition;
        rigidBodyComponent.AddForce(Vector3.right, ForceMode.VelocityChange);
        switch (direction)
        {
            case 1:
                //if 1 - moves right
                if (relativePosition.x < 3)
                {
                    translate = 1;
                    transform.Translate(new Vector3(.1f,0,0));
                }
                else
                {
                    direction = 0;
                }
                break;
            case 0:
                //if 0 - moves left
                if (relativePosition.x > -3)
                {
                    translate = -1;
                    transform.Translate(new Vector3(-.1f,0,0));
                }
                else
                {
                    direction = 1;
                }
                break;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
    }
}
